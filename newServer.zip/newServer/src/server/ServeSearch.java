package server;

import Admin.Restaurant;
import FileInputOutput.ReadWrite;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class ServeSearch extends Thread {
    Socket socket;
    PrintWriter out;
    BufferedReader in;

    ObjectInputStream objectIn;
    ObjectOutputStream objectOut;

    String[] command;
    int clientNumber, line;

    Object receivedRest;

    ServeSearch(Socket socket, int clientNumber) throws IOException {
        this.socket = socket;
        this.clientNumber = clientNumber;
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        start();
    }

    public void run() {
        while (!socket.isClosed()) {
            try {
                command = in.readLine().split("/");
            } catch (IOException e) {
                System.out.println("command Error");
            }
            switch (command[0]) {
                case "adminAdd":
                    receivedRest = receivedObject();
                    new ReadWrite().add((Restaurant) receivedRest);
                    break;
                case  "adminRemove" :
                    line = receivedLine();
                    new ReadWrite().remove(line);
                    break;
                case "adminEdit" :
                    line = receivedLine();
                    receivedRest = receivedObject();
                    new ReadWrite().edit(line, (Restaurant) receivedRest);
                    break;
                case "adminShow" :
                    sendRests();
                    break;
            }
        }
        System.out.println("serve is closed");
    }

    private Object receivedObject(){
        try {
            objectIn = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            Object received = objectIn.readObject();
            System.out.println("received :\n"+received);
            return received;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("can not received");
            return  null;
        }finally {
            try {
                objectIn.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private int receivedLine(){
        try {
            int line = in.read();
            System.out.println("received line :"+line);
        } catch (IOException e) {
            System.out.println("can not received line");
        }
        return 0;
    }

    private void sendRests(){
        ArrayList<Restaurant> restaurants = new ReadWrite().read();
        try {
            objectOut = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            objectOut.writeObject(restaurants);
            objectOut.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                objectOut.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

}
