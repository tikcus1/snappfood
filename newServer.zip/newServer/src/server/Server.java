package server;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static File restaurants;

    static int client = 0;
    public static void main(String[] args) throws IOException {

        System.out.println("server is running");

        ServerSocket serverSocket = new ServerSocket(9876);

        restaurants = new File("src/Data/restaurants.ser");


        while (true){
            Socket socket = serverSocket.accept();

            System.out.println("client "+ ++client + "connected");

            new ServeSearch(socket, client);
        }
    }
}
