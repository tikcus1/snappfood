package FileInputOutput;

import Admin.Restaurant;
import server.Server;

import java.io.*;
import java.util.ArrayList;

public class ReadWrite {

    FileInputStream fileIn ;
    ObjectInputStream objectFromFile ;

    FileOutputStream fileOut;
    ObjectOutputStream objectToFile;
    ArrayList<Admin.Restaurant> restaurants ;


    public ArrayList<Admin.Restaurant> read(){
        restaurants = new ArrayList<>();
        try {
            fileIn = new FileInputStream(Server.restaurants);
            objectFromFile = new ObjectInputStream(fileIn);
            while (true){
                Restaurant restaurant = (Restaurant) objectFromFile.readObject();
                restaurants.add(restaurant);
            }

        } catch (IOException e) {
            System.out.println("could not find file");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                fileIn.close();
                objectFromFile.close();
            } catch (IOException e) {
                System.out.println("could not close file");
            }
        }
        if (restaurants.size() != 0){
            restaurants.remove(0);
        }
        return restaurants;
    }

    private void write(ArrayList<Restaurant> restaurantArrayList){
        try {
            fileOut = new FileOutputStream(Server.restaurants);
            objectToFile = new ObjectOutputStream(fileOut);
            objectToFile.writeObject(null);
            for(Restaurant res: restaurantArrayList){
                objectToFile.writeObject(res);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                fileOut.close();
                objectToFile.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }

    public boolean add(Restaurant restaurant){
        ArrayList<Restaurant> restaurantArrayList = read();
        restaurantArrayList.add(restaurant);
        write(restaurantArrayList);
        return true ;
    }

    public boolean remove(int line){
        ArrayList<Restaurant> restaurantArrayList = read();
        restaurantArrayList.remove(line);
        write(restaurantArrayList);
        return true;
    }

    public boolean edit(int line, Restaurant restaurant){
        ArrayList<Restaurant> restaurantArrayList = read();
        restaurantArrayList.set(line, restaurant);
        write(restaurantArrayList);
        return true;
    }
}
