package server;

public class FoodClass {
    private String name;
    private String price;
    private double weight;
    enum type{
        traditional, pizza, salad, seafood, sandwiches, pasta, iranian;
    }
    private String pic;
}
