package code.main;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.Objects;

public class Main extends Application {

    public static Stage stage;
    public static Scene scene;

    public static Socket socket;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage){

        stage = primaryStage;

        try{
            socket = new Socket("localhost", 8335);

            //URL url = getClass().getResource("../../resource/FXML/userLogin.fxml");
            URL url = getClass().getResource("../../resource/FXML/logreg.fxml");
            AnchorPane anchorPane = FXMLLoader.load(Objects.requireNonNull(url));
            primaryStage.setTitle("login");
            scene = new Scene(anchorPane);
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();

        }catch (IOException exception ){
            System.out.println("server not found");
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Error");
            errorAlert.setContentText("Server not found");
            errorAlert.showAndWait();
            exception.printStackTrace();
            System.exit(1);
        }
    }
}

