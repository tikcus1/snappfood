package code.controller;

import code.main.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.Objects;

import static code.controller.UserLoginController.borderPane;

public class Main_menu_controller {

    int i, j;
    Socket socket;
    PrintWriter out;
    BufferedReader in ;
    @FXML
    BorderPane main_layout;

    @FXML
    Button home_button;

    @FXML
    Button profile_button;
    @FXML
    Button exit_button;

    public Main_menu_controller() throws IOException {
        this.socket = Main.socket;
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//        addFood("food");
    }

    public void exit(ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../../resource/FXML/userLogin.fxml"));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(loader.load()));
        stage.show();
    }

    public void profile(ActionEvent event) throws IOException {
        out.println("showProperties");
        setEnable(profile_button);
        addPro();
    }



    public void addPro() throws IOException {
        AnchorPane centerPane = (AnchorPane) borderPane.getCenter();

        URL url2 = getClass().getResource("../../resource/FXML/profile.fxml");
        AnchorPane profPane = FXMLLoader.load(url2);
//        profPane.getChildren().set(5, new ImageView("resource/pictures/profile/nature.jpg"));

        for (int i = 0 ; i < 5; i++){
            Label label = (Label) profPane.getChildren().get(i);
            label.setText(in.readLine());
        }

        centerPane.getChildren().set(0, profPane);


        Main.stage.setScene(Main.scene);
        Main.stage.show();
    }

    private void setEnable(Button button){
        home_button.setDisable(false);
        profile_button.setDisable(false);
        exit_button.setDisable(false);
        button.setDisable(true);
    }

    public void home(ActionEvent event) throws IOException {

        setEnable(home_button);

//        AnchorPane centerPane = (AnchorPane) borderPane.getCenter();
//        URL url = getClass().getResource("../../resource/FXML/home.fxml") ;
//        AnchorPane mainPane = FXMLLoader.load(Objects.requireNonNull(url));
//        centerPane.getChildren().set(0, mainPane);
        addRest();
        Main.stage.setScene(Main.scene);
        Main.stage.show();
    }

    public void addRest() throws IOException {

        URL url1  = UserLoginController.class.getResource("../../resource/FXML/home.fxml");
        AnchorPane mainPane = FXMLLoader.load(url1);
        VBox vBox = (VBox) mainPane.getChildren().get(0);
        ScrollPane scrollPane = (ScrollPane) vBox.getChildren().get(3);
        GridPane grid = (GridPane) scrollPane.getContent();

//        out.println("RestaurantsList");
//        int RestaurantCounts = in.read();
        int RestaurantCounts = 5;

        URL rest= UserLoginController.class.getResource("../../resource/FXML/one_rest.fxml");
        i = j = 0;
        for (int k = 0; k<RestaurantCounts; k++){
            //image az server TODO
            //properties az server TODO
            Image image = new Image("resource/pictures/icons/avatar.jpg");
            AnchorPane anchorPane = FXMLLoader.load(rest);
            anchorPane.setBackground(new Background(setBackGround(image)));
            //setProperties() TODO


            grid.add(anchorPane, i, j);
            if(i == 1) {
                j++;
                i = 0;
            }
            else {
                i++;
            }
        }
        borderPane.setCenter(mainPane);
    }


    private static BackgroundImage setBackGround(Image image){
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        return backgroundImage;
    }
}
