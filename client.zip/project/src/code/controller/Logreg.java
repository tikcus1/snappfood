package code.controller;

import code.main.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;

public class Logreg {

    public void login(ActionEvent event) throws IOException {
        URL url = getClass().getResource("../../resource/FXML/userLogin.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
    }

    public void register(ActionEvent event) throws IOException {
        URL url = getClass().getResource("../../resource/FXML/register.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
    }
}
