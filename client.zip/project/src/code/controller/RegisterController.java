package code.controller;

import code.main.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.Objects;

public class RegisterController {

    Socket socket ;
    PrintWriter out ;
    BufferedReader in ;

    @FXML
    TextField username_field;
    @FXML
    TextField confirm_password_field;
    @FXML
    TextField password_field;
    @FXML
    TextField email_field;
    @FXML
    TextField address_field;
    @FXML
    TextField phoneNumber_field;

    @FXML
    Text warning_text;

    @FXML
    Text email_warning;
    @FXML
    Text phone_warning;

    public RegisterController() throws IOException{
        this.socket = Main.socket;
        out = new PrintWriter(socket.getOutputStream(), true) ;
        in = new BufferedReader(new InputStreamReader(socket.getInputStream())) ;
    }

    public void register_button(ActionEvent event) throws IOException {
        if(checkValid(username_field.getText()) && checkValid(password_field.getText()) && check()) {
            if (checkConfirm()) {
                out.println("register/" + username_field.getText() + "/" + password_field.getText() + "/" +
                        email_field.getText() +"/"+ phoneNumber_field.getText()+"/"+address_field.getText());
                String serverAns =in.readLine();
                switch (serverAns) {
                    case "true":
                        login_button(event);
                        break;
                    case "repetitive":
                        warning_text.setText("username is in used");
                        break;
                    case "email":
                        warning_text.setText("email is in used");
                        break;
                    case "phone":
                        warning_text.setText("phoneNumber is in used");
                        break;
                }
            } else {
                warning_text.setText("confirm the password");
            }
        }
        else {
            System.out.println("war");
            warning_text.setText("use a-z & 0-9");
        }
    }

    private boolean checkConfirm() {
        return password_field.getText().equals(confirm_password_field.getText());
    }

    public void login_button(ActionEvent event) throws IOException {

        URL url = getClass().getResource("../../resource/FXML/userLogin.fxml");
        AnchorPane anchorPane = FXMLLoader.load(Objects.requireNonNull(url));

        Main.scene = new Scene(anchorPane);
        Main.stage.setScene(Main.scene);
    }

    private boolean checkValid(String str){
        char letter;
        for (int i = 0; i < str.length(); i++) {
            letter = str.charAt(i);
            if (!Character.toString(letter).matches("^[a-zA-Z0-9]*$"))
                return false;
        }
        return true;
    }

    private boolean checkPhone(){
        String str = phoneNumber_field.getText();
        Character letter;
        for (int i = 0; i < str.length(); i++) {
            letter = str.charAt(i);
            if (!Character.toString(letter).matches("^[0-9]*$"))
                return false;
        }
        return true;
    }

    private boolean checkEmail(){
        String str = email_field.getText();
        String str2 = "@gmail.com";
        String str3 = "@yahoo.com";
        return str.contains(str2) || str.contains(str3);
    }

    public boolean check(){
        boolean bool = true;
        email_warning.setVisible(false);
        phone_warning.setVisible(false);
        if (!checkEmail()) {
            email_warning.setVisible(true);
            bool = false;
        }
        if (!checkPhone()){
            phone_warning.setVisible(true);
            bool = false;
        }
        return bool;
    }
}
