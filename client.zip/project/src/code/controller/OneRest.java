package code.controller;

import code.main.Main;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;

import static code.controller.UserLoginController.borderPane;

public class OneRest {

    public void tmp(MouseEvent mouseEvent) throws IOException {
        System.out.println("clicked");
        AnchorPane centerPane = (AnchorPane) borderPane.getCenter();

        URL url2 = getClass().getResource("../../resource/FXML/Restaurant.fxml");
        AnchorPane restaurantPane = FXMLLoader.load(url2);
        centerPane.getChildren().set(0, restaurantPane);


        Main.stage.setScene(Main.scene);
        Main.stage.show();
    }
}
