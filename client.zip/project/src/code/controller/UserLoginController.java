package code.controller;
import code.main.Main;
import code.restaurant.Restaurant;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;

public class UserLoginController {

    static int i, j;
    @FXML
    TextField username_field ;

    @FXML
    PasswordField password_field ;

    @FXML
    Text password_error_field ;

    @FXML
    Text user_error_field;



    Socket socket ;
    PrintWriter out;
    BufferedReader in ;

    ObjectInputStream objectIn;

    ArrayList<Restaurant> restaurants ;

    public static BorderPane borderPane;

    public UserLoginController() throws IOException{
        this.socket = Main.socket;
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        objectIn = new ObjectInputStream(socket.getInputStream());
    }


    public void login_button(ActionEvent actionEvent) throws Exception {
        password_error_field.setText("");
        user_error_field.setText("");
        if(isEmpty()){
            out.println("login/"+username_field.getText()+"/"+password_field.getText()+"/");
            String tmp = in.readLine();
            if (tmp.contains("true")) {
                loggedIn(username_field.getText());
            }
            else {
                System.out.println("user not found");
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setHeaderText("Error");
                errorAlert.setContentText("User not found");
                errorAlert.showAndWait();
            }
        }
    }

    public void loggedIn(String userName) throws Exception{
        URL url = getClass().getResource("../../resource/FXML/main menu.fxml");
        borderPane = FXMLLoader.load(Objects.requireNonNull(url));

        //set top
        HBox hBox = (HBox) borderPane.getTop();
        Label label = (Label) hBox.getChildren().get(6);
        label.setText(userName);
        ImageView userProfile = (ImageView) hBox.getChildren().get(7);
//        userProfile.setImage(new Image("image Path"));TODO
        userProfile.setImage(new Image("resource/pictures/profile/nature.jpg"));

        addRest();
        Main.scene = new Scene(borderPane);
        Main.stage.setScene(Main.scene);

    }

    public boolean isEmpty(){
        boolean b = true;
        if(username_field.getText().equals("")) {
            user_error_field.setText("enter the username !");
            b = false;
        }
        if(password_field.getText().equals("")) {
            password_error_field.setText("enter the password !");
            b = false;
        }
        return b;
    }

    public void register(ActionEvent event) throws IOException {

        URL url = getClass().getResource("../../resource/FXML/register.fxml");
        AnchorPane anchorPane = FXMLLoader.load(Objects.requireNonNull(url));

        Main.scene = new Scene(anchorPane);
        Main.stage.setScene(Main.scene);
    }


    public static void addRest(String category){
        //TODO
        //get restaurants ArrayLists from server and removeIf(! type.equals(category)) and call addRest()
    }
    public void addRest() throws IOException, ClassNotFoundException {

        URL url1  = UserLoginController.class.getResource("../../resource/FXML/home.fxml");
        AnchorPane mainPane = FXMLLoader.load(url1);
        VBox vBox = (VBox) mainPane.getChildren().get(0);
        ScrollPane scrollPane = (ScrollPane) vBox.getChildren().get(3);
        GridPane grid = (GridPane) scrollPane.getContent();

        out.println("adminShow/");
        restaurants = new ArrayList<>();
        //int tmp = in.read();
        int tmp = Integer.parseInt(in.readLine());
        System.out.println("tmp: " + tmp);
        for (int i = 0; i < tmp; i++) {
            System.out.println(i);
            Object receivedObject = objectIn.readObject();
            restaurants.add((Restaurant) receivedObject);
        }
        System.out.println(restaurants);


        out.println("RestaurantList/");
        int RestaurantCounts = Integer.parseInt(in.readLine());
//        int RestaurantCounts = 5;

        URL rest= UserLoginController.class.getResource("../../resource/FXML/one_rest.fxml");
        i = j = 0;
        for (int k = 0; k<RestaurantCounts; k++){
            //image az server TODO
            //properties az server TODO
            Object receivedObject = objectIn.readObject();
            Object object = objectIn.readObject();
            restaurants = (ArrayList<Restaurant>) object;
            Restaurant restaurant = restaurants.get(i);
            Image image = new Image("resource/pictures/icons/avatar.jpg");

            AnchorPane anchorPane = FXMLLoader.load(rest);
            anchorPane.setBackground(new Background(setBackGround(image)));

            //setProperties() TODO
            Label nameLabel =(Label) anchorPane.getChildren().get(0);
            nameLabel.setText(restaurant.getName());
//            nameLabel.setText();

            grid.add(anchorPane, i, j);
            if(i == 1) {
                j++;
                i = 0;
            }
            else {
                i++;
            }
        }
        borderPane.setCenter(mainPane);
    }


    private static BackgroundImage setBackGround(Image image){
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        return backgroundImage;
    }

}