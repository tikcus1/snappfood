package code.controller;

import code.main.Main;
import javafx.event.ActionEvent;


import java.io.*;
import java.net.Socket;

public class Profile_controller {

    Socket socket;
    PrintWriter out;

    BufferedReader in;

    public Profile_controller() throws IOException {
        this.socket = Main.socket;
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

}
