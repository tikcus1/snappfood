package code.controller;

import javafx.fxml.FXML;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;

import javafx.event.ActionEvent;
import java.io.IOException;

public class home_controller {
    @FXML
    MenuButton category;

    @FXML
    private void changeCategory(ActionEvent event) throws IOException {
        MenuItem menuItem = (MenuItem) event.getSource();
        System.out.println(menuItem.getText());
        menuItem.getText();
        UserLoginController.addRest(menuItem.getText());
    }

}
