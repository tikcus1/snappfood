import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.awt.event.ActionEvent;

public class TmpController {

    @FXML
    private Button button1;
    public void header(javafx.event.ActionEvent actionEvent) throws Exception {
        new Logged().start(main.Main.stage);
    }
}
