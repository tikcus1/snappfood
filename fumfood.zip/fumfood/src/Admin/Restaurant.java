package Admin;

import com.sun.xml.internal.ws.wsdl.writer.document.http.Address;
import javafx.util.Pair;

import java.util.ArrayList;

public class Restaurant {
    //fields
    private String name;
    private String address;
    private String work_time;
    private String pic;
    private Pair<String, Integer> type;
    boolean vis;
    ArrayList<Pair<FoodClass, Integer>> foods = new ArrayList<>();

    //constructors
    public Restaurant(String name, String address, String work_time, String pic, Pair<String, Integer> type, ArrayList<Pair<FoodClass, Integer>> foods) {
        this.name = name;
        this.address = address;
        this.work_time = work_time;
        this.pic = pic;
        this.type = type;
        this.foods = foods;
        vis = true;
    }

    //methods

}
