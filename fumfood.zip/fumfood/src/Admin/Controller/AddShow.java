package Admin.Controller;


import Admin.Restaurant;
import Admin.OpenShowList;
import javafx.util.Pair;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class AddShow {
    public void add_restaurant() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("name?");
        String n = scanner.next();

        System.out.println("address?");
        String a = scanner.next();

        System.out.println("work time?");
        String w = scanner.next();

        System.out.println("picture?");
        String p = scanner.next();

        System.out.println("where can eat?(in/out)");
        String wh1 = scanner.next();
        if (wh1.compareTo("in") == 0) {
            System.out.println("how many table?");
        }
        else {
            System.out.println("how many courier?");
        }
        int wh2 = scanner.nextInt();
        Pair<String, Integer> wh = new Pair<>(wh1, wh2);

        //File file = new File("../files/restaurants.txt");
        File file = new File("restaurant.txt");
        try (FileWriter fw = new FileWriter("restaurants.txt", true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter output = new PrintWriter(bw, true)) {
            output.println(new Restaurant(n, a, w, p, wh, new ArrayList<>()));
        } catch (FileNotFoundException e) {
            System.out.println("nist");
        }
        //Restaurant restaurant1 = new Restaurant(n, a, w, p, wh, new ArrayList<>());
        // restaurant[current_restaurant++] = ...
        //save in file*/
    }
    public void show_restaurant() throws Exception {
        new OpenShowList().start(main.Main.stage);
        //System.out.println("kh");
    }

}
