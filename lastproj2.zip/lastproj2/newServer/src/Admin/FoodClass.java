package Admin;

public class FoodClass {
    //fields
    private String name;
    private String price;
    private double weight;

    enum type{
        traditional, pizza, salad, seafood, sandwiches, pasta, iranian;
    }
    private String pic;

    //constructors


    public FoodClass(String name, String price, double weight, String pic) {
        this.name = name;
        this.price = price;
        this.weight = weight;
        this.pic = pic;
    }

    //methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}
