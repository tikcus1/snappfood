package Admin.Controller;


import Admin.Restaurant;
import Admin.OpenShowList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Pair;
import main.Main;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import static Admin.Controller.RestDetails.*;


public class AddShow {
    int i, j;

    static Socket socket;
    static PrintWriter out;

    BufferedReader in;
    ObjectInputStream objectIn;
    static ObjectOutputStream outputStream;

    public static ArrayList<Restaurant> restaurants;

    public AddShow() {
        String serverHost = "localhost"; // آدرس IP سرور
        int serverPort = 6776;
        try {
            // ایجاد اتصال به سرور
            socket = new Socket(serverHost, serverPort);

            out = new PrintWriter(socket.getOutputStream(), true);

            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//            objectIn = new ObjectInputStream(socket.getInputStream());


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void add_restaurant() throws Exception {
        Scanner scanner = new Scanner(System.in);

        URL url = getClass().getResource("../FXML/rest_details.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);

///////////////////////////////////////////////////////////////////////////////////////////
      /*
         // پورت سرور
        out.println("adminAdd/");

        // ایجاد شیء برای ارسال به سرور
        Restaurant restaurant = restDetail;
        System.out.println(restaurant);

        // تبدیل و ارسال شیء
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        outputStream.writeObject(restaurant);
        outputStream.flush();
//        outputStream.close();

        // بستن اتصال
//            socket.close();

        System.out.println("شیء با موفقیت ارسال شد.");

        //new ShowList().grid.getChildren().add(new OneRest(n).one);

       */
    }

////////////////////////////////////////////////////////////////////////////////////
    public void show_restaurant() throws Exception {
        objectIn = new ObjectInputStream(socket.getInputStream());

        out.println("adminShow");
        restaurants = new ArrayList<>();
        restaurants =(ArrayList<Restaurant>) objectIn.readObject();
        System.out.println(restaurants);

        URL url1 = getClass().getResource("../FXML/show_list.fxml");
        AnchorPane anchorPane1 = FXMLLoader.load(url1);
        for (Restaurant r: restaurants) {
            //System.out.println(r.getName());
            add(anchorPane1, r.getVis(), r.getName(), r.getPic());
        }

//        add(n, p);
        /*URL url1 = getClass().getResource("../FXML/show_list.fxml");
        AnchorPane anchorPane1 = FXMLLoader.load(url1);*/
        Scene scene = new Scene(anchorPane1);
        Main.stage.setScene(scene);
       //new OpenShowList().start(main.Main.stage);
    }

    public void add(AnchorPane anchorPane1, boolean b, String n, String p) throws Exception {
        /*URL url1 = getClass().getResource("../FXML/show_list.fxml");
        AnchorPane anchorPane1 = FXMLLoader.load(url1);*/
        GridPane grid = (GridPane) anchorPane1.getChildren().get(0);

        URL url2 = getClass().getResource("../FXML/one_rest.fxml");
        AnchorPane anchorPane2 = FXMLLoader.load(url2);
        // images/food.jpg p = food.jpg
        Image image = new Image("images/" + p);
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        Background background = new Background(backgroundImage);
        anchorPane2.setBackground(background);
        Label label = (Label) anchorPane2.getChildren().get(0);
        label.setText(n);
        anchorPane2.setOpacity(b? 1: 0.3);

        grid.add(anchorPane2, j, i);
        if (j == 2) {
            i++;
            j = 0;
        } else {
            j++;
        }
       /* Scene scene = new Scene(anchorPane1);
        Main.stage.setScene(scene);*/
    }
    static void removeObject(int n){
        out.println("adminRemove/"+n);
    }

    public static void editObject(int line, Restaurant this_rest) throws IOException {
        out.println("adminEdit/"+ line);

        outputStream = new ObjectOutputStream(socket.getOutputStream());
        outputStream.writeObject(this_rest);
        outputStream.flush();
    }
}