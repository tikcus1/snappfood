package Admin.Controller;

import Admin.Restaurant;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.util.Pair;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import static Admin.Controller.AddShow.*;

public class RestDetails {
    public static Restaurant restDetail;

    public TextField n;
    public TextField a;
    public TextField w;
    public TextField p;
    public TextField wh1;
    public TextField wh2;

    public void finished(ActionEvent actionEvent) throws IOException {
        Pair<String, Integer> wh = new Pair<>(wh1.getText(), Integer.parseInt(wh2.getText()));
        restDetail = new Restaurant(n.getText(), a.getText(), w.getText(), p.getText(), wh, new ArrayList<>());
        // پورت سرور
        out.println("adminAdd/");

        // ایجاد شیء برای ارسال به سرور
        Restaurant restaurant = restDetail;
        System.out.println(restaurant);

        // تبدیل و ارسال شیء
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        outputStream.writeObject(restaurant);
        outputStream.flush();
//        outputStream.close();

        // بستن اتصال
//            socket.close();

        System.out.println("شیء با موفقیت ارسال شد.");

    }
}
