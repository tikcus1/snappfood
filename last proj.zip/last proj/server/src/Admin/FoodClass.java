package Admin;

public class FoodClass {
    //fields
    private String name;
    private double price;
    private double weight;

    public enum Type{
        traditional, pizza, salad, seafood, sandwiches, pasta, iranian;
    }

    private Type type;
    private String pic;

    //constructors

    public FoodClass(String name, double price, double weight, Type type, String pic) {
        this.name = name;
        this.price = price;
        this.weight = weight;
        this.type = type;
        this.pic = pic;
    }

    //methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}
