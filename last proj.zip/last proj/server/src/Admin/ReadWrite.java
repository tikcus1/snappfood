package Admin;

import server.Server;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Objects;

public class ReadWrite {

    Object receivedObject;
    /*FileInputStream fileIn;
    ObjectInputStream objectIn;*/


//    public ReadWrite(Object receivedObject){
//        this.receivedObject=receivedObject;
//    }

    public ReadWrite() throws IOException {
        /*fileIn = new FileInputStream("src/Data/restaurants.ser");
        objectIn = new ObjectInputStream(fileIn);*/
    }

    public void setReceivedObject(Object receivedObject){
        this.receivedObject = receivedObject;
    }

    public void write(){
        ArrayList<Restaurant> restaurantArrayList = read();
        try(/*ObjectInputStream objectIn = new ObjectInputStream(socket.getInputStream());//in*/
            FileOutputStream fileOut = new FileOutputStream(Server.restaurants);//out
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut)){//out
            //Object receivedObject = objectIn.readObject();//in
            objectOut.writeObject(null);
            for(Restaurant res: restaurantArrayList){
                objectOut.writeObject(res);
            }

            objectOut.writeObject(receivedObject);


            System.out.println("Received: " + receivedObject.toString());

        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public ArrayList<Restaurant> read(){
        ArrayList<Restaurant> restaurants = new ArrayList<>();
        try (FileInputStream fileIn = new FileInputStream(Server.restaurants);
           ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
                while(true) {
                    try {
                        Restaurant restaurant = (Restaurant) objectIn.readObject();
                        restaurants.add(restaurant);
                    } catch (ClassNotFoundException e) {
                        System.out.println("class nis");
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
//                System.out.println("file finished");
        }
        restaurants.remove(0);
//        System.out.println(restaurants.size());
        return restaurants;
    }



//    try (FileInputStream fileIn = new FileInputStream("restaurants.ser");
//    ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
//
//        restaurant = (Restaurant) objectIn.readObject();
//        System.out.println("didi" + restaurant.toString());
//
//    } catch (IOException | ClassNotFoundException e) {
//        System.out.println("riiiiiiiiiiiiiiiiidiiiiiiiiiiiiii");
//    }

}
