public class LoggedController {
}
