package Admin.Controller;

import Admin.FoodClass;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.util.Pair;

import java.io.IOException;
import java.util.Scanner;

import static Admin.Controller.AddShow.restaurants;
import static Admin.Controller.OneRest.this_rest;

public class OneFood {

    public void remove(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        anchorPane.setVisible(false);
        int l = Admin.Controller.OneRest.getLine(anchorPane);
        Pair<FoodClass, Integer> this_food = this_rest.getFoods().get(l);
        Admin.Controller.OneRest.changeLine(anchorPane);
        this_rest.getFoods().remove(this_food);
        // send to server to delete from file
        //AddShow.editObject(OneRest.line, this_rest);
    }

    Scanner scanner = new Scanner(System.in);
    public void edit(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        int l = Admin.Controller.OneRest.getLine(anchorPane);
        Pair<FoodClass, Integer> this_food = this_rest.getFoods().get(l);

        System.out.println("name: 1");
        System.out.println("price: 2");
        System.out.println("weight: 3");
        System.out.println("type: 4");
        System.out.println("picture: 5");
        System.out.println("how many: 6");
        int which2 = scanner.nextInt();
        switch (which2) {
            case 1:
                String n = scanner.next();
                this_food.getKey().setName(n);
                Label label = (Label) anchorPane.getChildren().get(0);
                label.setText(n);
                break;
            case 2:
                double p = scanner.nextDouble();
                this_food.getKey().setPrice(p);
                break;
            case 3:
                double w = scanner.nextDouble();
                this_food.getKey().setPrice(w);
                break;
            case 4:
                FoodClass.Type type = FoodClass.Type.valueOf(scanner.next());
                this_food.getKey().setType(type);
                break;
            case 5:
                String pic = scanner.next();
                this_food.getKey().setPic(pic);
                Image image = new Image("images/" + pic);
                BackgroundImage backgroundImage = new BackgroundImage(image,
                        BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                        BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
                Background background = new Background(backgroundImage);
                anchorPane.setBackground(background);
                break;
            case 6:
                int h = scanner.nextInt();
                this_food = new Pair<>(this_food.getKey(), h);
                break;
        }
        //AddShow.editObject(OneRest.line, this_rest);
    }
}
