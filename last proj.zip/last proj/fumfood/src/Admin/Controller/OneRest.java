package Admin.Controller;

import Admin.FoodClass;
import Admin.Restaurant;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.util.Pair;
import main.Main;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
public class OneRest {

    public static int line;
    public static Restaurant this_rest;
    static ArrayList<Restaurant> restaurants = AddShow.restaurants;

    public void visibility(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        line = getLine(anchorPane);
        this_rest = restaurants.get(line);
        anchorPane.setOpacity(this_rest.getVis()? 0.3: 1);
        this_rest.setVis(!this_rest.getVis());
        // mifresti be server ke pak kone az file
        //mitooni safhe ham dobare load koni  vali felan na
        AddShow.editObject(line, this_rest);
    }

    public void remove(ActionEvent actionEvent) {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        anchorPane.setVisible(false);
        int line = getLine(anchorPane);
        this_rest = restaurants.get(line);
        changeLine(anchorPane);
        restaurants.remove(this_rest);
        // send to server to delete from file
        AddShow.removeObject(line);
    }

    Scanner scanner = new Scanner(System.in);
    public void editProperty(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        line = getLine(anchorPane);
        this_rest = restaurants.get(line);

        System.out.println("change name: 1");
        System.out.println("change address: 2");
        System.out.println("change work_time: 3");
        System.out.println("change pic: 4");
        System.out.println("change type: 5");
        int which = scanner.nextInt();
        switch (which) {
            case 1 :
                String n = scanner.next();
                this_rest.setName(n);
                Label label = (Label) anchorPane.getChildren().get(0);
                label.setText(n);
                break;
            case 2:
                String a = scanner.next();
                this_rest.setAddress(a);
                break;
            case 3:
                String w = scanner.next();
                this_rest.setWork_time(w);
                break;
            case 4:
                String p = scanner.next();
                this_rest.setPic(p);
                Image image = new Image("images/" + p);
                BackgroundImage backgroundImage = new BackgroundImage(image,
                        BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                        BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
                Background background = new Background(backgroundImage);
                anchorPane.setBackground(background);
                break;
            case 5:
                String t = scanner.next();
                int table = scanner.nextInt();
                this_rest.setType(new Pair<>(t, table));
                break;
        }
        // send to server to delete from file
        AddShow.editObject(line, this_rest);
    }

    public void editFoods(ActionEvent actionEvent) throws Exception {

        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        line = getLine(anchorPane);
        this_rest = restaurants.get(line);

        URL url = getClass().getResource("../FXML/add_show_food.fxml");
        AnchorPane anchorPane1 = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane1);
        Main.stage.setScene(scene);



       /*URL url1 = getClass().getResource("../FXML/show_list.fxml");
        AnchorPane anchorPane1 = FXMLLoader.load(url1);

        for (Pair<FoodClass, Integer> f: this_rest.getFoods()) {
            //System.out.println(r.getName());
            add(anchorPane1, f.getKey().getName(), f.getKey().getPic());

        }

        Scene scene = new Scene(anchorPane1);
        Main.stage.setScene(scene);*/


        // add food & show food
        // show food: every food (edit & remove)



        /*System.out.println("add: 1");
        System.out.println("remove: 2");
        System.out.println("edit: 3");
        int which = scanner.nextInt();
        switch (which) {
            case 1 :
                System.out.println("name?");
                String n = scanner.next();
                System.out.println("price?");
                double p = scanner.nextDouble();
                System.out.println("type?");
                FoodClass.Type type = FoodClass.Type.valueOf(scanner.next());
                System.out.println("picture?");
                String pic = scanner.next();
                FoodClass food = new FoodClass(n, p, 1.0, type ,"images/" + pic);
                System.out.println("how many?");
                int c = scanner.nextInt();
                this_rest.getFoods().add(new Pair<>(food, c));
                break;
            case 2:
                String n2 = scanner.next();
                for (Pair<FoodClass, Integer> f: this_rest.getFoods()) {
                    if (f.getKey().getName().equals(n2)) {
                        this_rest.getFoods().remove(f);
                        break;
                    }
                }
                break;
            case 3:
                System.out.println("name: 1");
                System.out.println("price: 2");
                System.out.println("weight: 3");
                System.out.println("type: 4");
                System.out.println("picture: 5");
                System.out.println("how many: 6");
                int which2 = scanner.nextInt();
                switch (which2) {
                    case 1:
                        String n3 = scanner.next();
                        //this_rest.getFoods().
                        break;
                    case 2:

                        break;
                    case 3:

                        break;

                    case 4:

                        break;
                    case 5:

                        break;
                }
                break;
        }*/
    }

    public static void changeLine(AnchorPane anchorPane) {
        GridPane gridPane = (GridPane) anchorPane.getParent();

        int row = gridPane.getRowIndex(anchorPane);
        int col = gridPane.getColumnIndex(anchorPane);
////////////////////////////////////////////////////////////////////////1
        //System.out.println(gridPane.getChildren());
        gridPane.getChildren().remove(row * 3 + col);

        while(row * 3 + col < restaurants.size() - 1) {
            radiusLine(gridPane, row, col);
            if(col == 2) {
                row++;
                col = 0;
            }
            else {
                col++;
            }
        }
        //AnchorPane anchorPaneDeleted = (AnchorPane) gridPane.getChildren().get(row * 3 + col);
       // anchorPaneDeleted.setVisible(false);
    }
    public static void radiusLine(GridPane gridPane, int row, int col) {
        int prow = row;
        int pcol = col;
        if(col == 2) {
            row++;
            col = 0;
        }
        else {
            col++;
        }
//////////////////////////////////////////////////////////////////////////////////////2
        //System.out.println(gridPane.getChildren());

        AnchorPane anchorPane = (AnchorPane) gridPane.getChildren().get(row * 3 + col - 1);
        gridPane.getChildren().remove(row * 3 + col - 1);
///////////////////////////////////////////////////////////////////////////////////////////3
        //System.out.println(gridPane.getChildren());

        gridPane.add(anchorPane, pcol, prow);
//////////////////////////////////////////////////////////////////////////////////////////4
        //System.out.println(gridPane.getChildren());

        //System.out.println(gridPane.getChildren().get(row * 3 + col - 1));
        for (int i = row * 3 + col - 1; i < gridPane.getChildren().size() - 1; i++) {
            gridPane.getChildren().add(gridPane.getChildren().remove(row * 3 + col - 1));
        }
//////////////////////////////////////////////////////////////////////////////////////////5
        //System.out.println(gridPane.getChildren());
    }
    public static int getLine(AnchorPane anchorPane) {
        //Button button = (Button) actionEvent.getSource();
        //AnchorPane anchorPane = (AnchorPane) button.getParent();
        GridPane gridPane = (GridPane) anchorPane.getParent();
        int row = gridPane.getRowIndex(anchorPane);
        int col = gridPane.getColumnIndex(anchorPane);
        //System.out.println(row);
        //System.out.println(col);
        return row * 3 + col;
    }
}
