package Admin.Controller;

import Admin.FoodClass;
import Admin.Restaurant;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.util.Pair;

import java.io.IOException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
public class OneRest {

    int line;
    ArrayList<Restaurant> restaurants = AddShow.restaurants;

    public void visibility(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        int line = getLine(anchorPane);
        Restaurant this_rest = restaurants.get(line);
        anchorPane.setOpacity(this_rest.getVis()? 0.3: 1);
        this_rest.setVis(!this_rest.getVis());
        // mifresti be server ke pak kone az file
        //mitooni safhe ham dobare load koni  vali felan na
        //AddShow.editObject(line, this_rest);
    }

    public void remove(ActionEvent actionEvent) {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        anchorPane.setVisible(false);
        int line = getLine(anchorPane);
        Restaurant this_rest = restaurants.get(line);
        changeLine(anchorPane);
        restaurants.remove(this_rest);
        // send to server to delete from file
        AddShow.removeObject(line);
    }

    Scanner scanner = new Scanner(System.in);
    public void editProperty(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        int line = getLine(anchorPane);
        Restaurant this_rest = restaurants.get(line);

        System.out.println("change name: 1");
        System.out.println("change address: 2");
        System.out.println("change work_time: 3");
        System.out.println("change pic: 4");
        System.out.println("change type: 5");
        System.out.println("change vis: 6");
        int which = scanner.nextInt();
        switch (which) {
            case 1 :
                String n = scanner.next();
                this_rest.setName(n);
                Label label = (Label) anchorPane.getChildren().get(0);
                label.setText(n);
                break;
            case 2:
                String a = scanner.next();
                this_rest.setAddress(a);
                break;
            case 3:
                String w = scanner.next();
                this_rest.setWork_time(w);
                break;
            case 4:
                String p = scanner.next();
                this_rest.setPic(p);
                Image image = new Image("images/" + p);
                BackgroundImage backgroundImage = new BackgroundImage(image,
                        BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                        BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
                Background background = new Background(backgroundImage);
                anchorPane.setBackground(background);
                break;
            case 5:
                String t = scanner.next();
                int table = scanner.nextInt();
                this_rest.setType(new Pair<>(t, table));
                break;
            case 6:
                boolean b = scanner.nextBoolean();
                this_rest.setVis(b);
                visibility(actionEvent);
                break;
        }
        // send to server to delete from file
        AddShow.editObject(line, this_rest);
    }

    public void editFoods(ActionEvent actionEvent) {
        Button button = (Button) actionEvent.getSource();
        AnchorPane anchorPane = (AnchorPane) button.getParent();
        int line = getLine(anchorPane);
        Restaurant this_rest = restaurants.get(line);
        // name price  weight type(traditional, pizza, salad, seafood, sandwiches, pasta, iranian) pic

        System.out.println("add: 1");
        System.out.println("remove: 2");
        System.out.println("edit: 3");
        int which = scanner.nextInt();
        switch (which) {
            case 1 :
                String n1 = scanner.next();
                FoodClass food = new FoodClass(n1, "", 1.0, "images/food.jpg");
                this_rest.getFoods().add(new Pair<>(food, 5));
                break;
            case 2:
                String n2 = scanner.next();
                this_rest.getFoods().remove(0);
                break;
            case 3:

                break;
        }
    }

    public void changeLine(AnchorPane anchorPane) {
        GridPane gridPane = (GridPane) anchorPane.getParent();

        int row = gridPane.getRowIndex(anchorPane);
        int col = gridPane.getColumnIndex(anchorPane);
////////////////////////////////////////////////////////////////////////1
        //System.out.println(gridPane.getChildren());
        gridPane.getChildren().remove(row * 3 + col);

        while(row * 3 + col < restaurants.size() - 1) {
            radiusLine(gridPane, row, col);
            if(col == 2) {
                row++;
                col = 0;
            }
            else {
                col++;
            }
        }
        //AnchorPane anchorPaneDeleted = (AnchorPane) gridPane.getChildren().get(row * 3 + col);
       // anchorPaneDeleted.setVisible(false);
    }
    public void radiusLine(GridPane gridPane, int row, int col) {
        int prow = row;
        int pcol = col;
        if(col == 2) {
            row++;
            col = 0;
        }
        else {
            col++;
        }
//////////////////////////////////////////////////////////////////////////////////////2
        //System.out.println(gridPane.getChildren());

        AnchorPane anchorPane = (AnchorPane) gridPane.getChildren().get(row * 3 + col - 1);
        gridPane.getChildren().remove(row * 3 + col - 1);
///////////////////////////////////////////////////////////////////////////////////////////3
        //System.out.println(gridPane.getChildren());

        gridPane.add(anchorPane, pcol, prow);
//////////////////////////////////////////////////////////////////////////////////////////4
        //System.out.println(gridPane.getChildren());

        //System.out.println(gridPane.getChildren().get(row * 3 + col - 1));
        for (int i = row * 3 + col - 1; i < gridPane.getChildren().size() - 1; i++) {
            gridPane.getChildren().add(gridPane.getChildren().remove(row * 3 + col - 1));
        }
//////////////////////////////////////////////////////////////////////////////////////////5
        //System.out.println(gridPane.getChildren());
    }
    public int getLine(AnchorPane anchorPane) {
        //Button button = (Button) actionEvent.getSource();
        //AnchorPane anchorPane = (AnchorPane) button.getParent();
        GridPane gridPane = (GridPane) anchorPane.getParent();
        int row = gridPane.getRowIndex(anchorPane);
        int col = gridPane.getColumnIndex(anchorPane);
        //System.out.println(row);
        //System.out.println(col);
        return row * 3 + col;
    }
}
