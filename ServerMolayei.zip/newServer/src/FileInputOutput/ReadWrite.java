package FileInputOutput;

import Admin.Restaurant;
import server.ServeSearch;
import server.Server;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

public class ReadWrite{

    FileInputStream fileIn ;
    ObjectInputStream objectFromFile ;

    FileOutputStream fileOut;
    ObjectOutputStream objectToFile;
    ArrayList<Admin.Restaurant> restaurants ;


    public ArrayList<Admin.Restaurant> read(){
        restaurants = new ArrayList<>();
        try {
            fileIn = new FileInputStream(Server.restaurants);
            objectFromFile = new ObjectInputStream(fileIn);
            try{
                while (true){
                    Restaurant restaurant = (Restaurant) objectFromFile.readObject();
                    restaurants.add(restaurant);
                }
            }catch (IOException exception){
            }

        } catch (IOException e) {
            System.out.println("could not find file");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                fileIn.close();
            } catch (IOException e) {
                System.out.println("could not close file");
            }
        }

        restaurants.removeIf(Objects::isNull);

        return restaurants;
    }

    private void write(ArrayList<Restaurant> restaurantArrayList){
        try {
            fileOut = new FileOutputStream(Server.restaurants);
            objectToFile = new ObjectOutputStream(fileOut);
            objectToFile.writeObject(null);
            for(Restaurant res: restaurantArrayList){
                objectToFile.writeObject(res);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                fileOut.close();
                objectToFile.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }

    public void add(Restaurant restaurant){
        ArrayList<Restaurant> restaurantArrayList = read();
//        ArrayList<Restaurant> restaurantArrayList = new ArrayList<>();
        restaurantArrayList.add(restaurant);
        write(restaurantArrayList);
        System.out.println("added : "+ restaurantArrayList);
    }

    public void remove(int line){
        ArrayList<Restaurant> restaurantArrayList = read();
        restaurantArrayList.remove(line);
        System.out.println("new Array:\n"+restaurantArrayList);
        write(restaurantArrayList);
    }

    public boolean edit(int line, Restaurant restaurant){
        ArrayList<Restaurant> restaurantArrayList = read();
        restaurantArrayList.set(line, restaurant);
        write(restaurantArrayList);
        return true;
    }

    public void changeVis(int line) {
        ArrayList<Restaurant> restaurantArrayList = read();
        Restaurant restaurant = restaurantArrayList.get(line);
        restaurant.setVis(!restaurant.getVis());
        write(restaurantArrayList);
    }
}
