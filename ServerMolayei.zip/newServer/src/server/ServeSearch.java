package server;

import Admin.Restaurant;
import FileInputOutput.ReadWrite;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class ServeSearch extends Thread {
    static public Socket socket;
    PrintWriter out;
    BufferedReader in;

    ObjectInputStream objectIn;
    InputStream inputStream;
    ObjectOutputStream objectOut;

    String[] command;
    int clientNumber, line;

    Object receivedRest;

    ServeSearch(Socket socket, int clientNumber) throws IOException {
        this.socket = socket;
        this.clientNumber = clientNumber;
        inputStream = socket.getInputStream();

        in = new BufferedReader(new InputStreamReader(inputStream));
        out = new PrintWriter(socket.getOutputStream(), true);

        objectIn = new ObjectInputStream(socket.getInputStream());
        objectOut = new ObjectOutputStream(socket.getOutputStream());



        start();
    }

    public void run() {

        while (!socket.isClosed()) {
            System.out.println("umadam to");

            try {
//                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String str= in.readLine();
                System.out.println(str);
                if (str != null)
                    command = str.split("/");
            } catch (IOException e) {
                System.out.println("command Error");
                command[0]="Exit";
                try {
                    socket.close();
                } catch (IOException ex) {
                    System.out.println("socket can not close");
                }
            }
            switch (command[0]) {
                case "adminAdd":
//                    try {
//                        objectIn = new ObjectInputStream(inputStream);
//                    } catch (IOException e) {
//                        System.out.println("46");
//                    }
                    receivedRest = receivedObject();
                    new ReadWrite().add((Restaurant) receivedRest);

                    break;
                case  "adminRemove" :
                    line = Integer.parseInt(command[1]);
                    new ReadWrite().remove(line);
                    break;
                case "adminEdit" :
                    System.out.println("edit");
                    line = Integer.parseInt(command[1]);
                    System.out.println("editttttt");
                    receivedRest = receivedObject();
                    System.out.println("edit "+ line);
                    new ReadWrite().edit(line, (Restaurant) receivedRest);
                    break;
                case "adminShow" :
                    sendRests();
                    break;
                case "adminVis" :
                    System.out.println("change vis");
                    line = Integer.parseInt(command[1]);
                    new ReadWrite().changeVis(line);
                    break;
            }
        }
        System.out.println("serve is closed");
    }

    private Object receivedObject(){

        try {
            Object received = objectIn.readObject();
            System.out.println("received :\n"+received);
            return received;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("can not received");
            return  null;
        }
    }

//    private int receivedLine(){
//        try {
//            int line = in.read();
//            System.out.println("received line :"+line);
//        } catch (IOException e) {
//            System.out.println("can not received line");
//        }
//        return 0;
//    }

    private void sendRests(){
        ArrayList<Restaurant> restaurants = new ReadWrite().read();
        try {
            objectOut.writeObject(restaurants);
            objectOut.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
