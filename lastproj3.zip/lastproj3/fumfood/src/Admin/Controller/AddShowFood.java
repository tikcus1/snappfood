package Admin.Controller;

import Admin.FoodClass;
import Admin.Restaurant;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.util.Pair;
import main.Main;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

import static Admin.Controller.OneRest.this_rest;

public class AddShowFood {
    private int i, j;
    public void add_food(ActionEvent actionEvent) throws IOException {
        URL url = getClass().getResource("../FXML/food_details.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        /*Scanner scanner = new Scanner(System.in);
        System.out.println("name?");
        String n = scanner.next();
        System.out.println("price?");
        double p = scanner.nextDouble();
        System.out.println("weight?");
        double w = scanner.nextDouble();
        System.out.println("type?");
        FoodClass.Type type = FoodClass.Type.valueOf(scanner.next());
        System.out.println("picture?");
        String pic = scanner.next();
        FoodClass food = new FoodClass(n, p, w, type ,"images/" + pic);
        System.out.println("how many?");
        int c = scanner.nextInt();
        this_rest.getFoods().add(new Pair<>(food, c));
        //AddShow.editObject(OneRest.line, this_rest);*/
    }
    public void show_food(ActionEvent actionEvent) throws IOException {
        URL url1 = getClass().getResource("../FXML/show_list.fxml");
        AnchorPane anchorPane1 = FXMLLoader.load(url1);

        for (Pair<FoodClass, Integer> f: this_rest.getFoods()) {
            System.out.println(f.getKey().getName() + " " + f.getKey().getPic());
            add(anchorPane1, f.getKey().getName(), f.getKey().getPic());

        }

        Scene scene = new Scene(anchorPane1);
        Main.stage.setScene(scene);
    }

    private void add(AnchorPane anchorPane1, String name, String pic) throws IOException {
        GridPane grid = (GridPane) anchorPane1.getChildren().get(0);

        URL url2 = getClass().getResource("../FXML/one_food.fxml");
        AnchorPane anchorPane2 = FXMLLoader.load(url2);
        // images/food.jpg p = food.jpg
        Image image = new Image("images/food.jpg");
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        Background background = new Background(backgroundImage);
        anchorPane2.setBackground(background);
        Label label = (Label) anchorPane2.getChildren().get(0);
        label.setText(name);
        grid.add(anchorPane2, j, i);
        if (j == 2) {
            i++;
            j = 0;
        } else {
            j++;
        }
    }
}
