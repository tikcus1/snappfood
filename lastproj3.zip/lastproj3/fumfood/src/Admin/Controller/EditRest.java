package Admin.Controller;

import Admin.Restaurant;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Pair;
import main.Main;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import static Admin.Controller.OneRest.*;

public class EditRest {
    public TextField n;
    public TextField a;
    public TextField w;
    public TextField p;
    public TextField wh1;
    public TextField wh2;

    public void finished(ActionEvent actionEvent) throws IOException {
        Pair<String, Integer> wh = new Pair<>(wh1.getText(), Integer.parseInt(wh2.getText()));
        Restaurant new_rest = new Restaurant(n.getText(), a.getText(), w.getText(), p.getText(), wh, new ArrayList<>());
        AddShow.editObject(line, new_rest);
        //back(actionEvent);
        URL url = getClass().getResource("../FXML/add_show.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();
    }

    public void back(ActionEvent actionEvent) throws IOException {
        URL url = getClass().getResource("../FXML/add_show.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();
        // make show_restaurants static
        //TODO
        //AddShow.show_restaurants();
    }
}
