package Admin.Controller;

import Admin.FoodClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Pair;
import main.Main;

import java.io.IOException;
import java.net.URL;

import static Admin.Controller.OneRest.line;
import static Admin.Controller.OneRest.this_rest;

public class FoodDetails {
    public TextField na;
    public TextField pr;
    public TextField w;
    public TextField t;
    public TextField pic;
    public TextField h;
    public void finished(ActionEvent actionEvent) throws IOException {
        FoodClass.Type type = FoodClass.Type.valueOf(t.getText());
        FoodClass food = new FoodClass(na.getText(), Double.parseDouble(pr.getText()), Double.parseDouble(w.getText()), type, pic.getText());
        this_rest.getFoods().add(new Pair<>(food, Integer.parseInt(h.getText())));
        System.out.println(this_rest.getFoods().get(0).getKey().getName());
        System.out.println(line + "______________" + this_rest);
        AddShow.editObject(line, this_rest);
        // line ro delete & this_rest add
    }

    public void back(ActionEvent actionEvent) throws IOException {
        URL url = getClass().getResource("../FXML/add_show_food.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();
    }
}
